import "dotenv/config";
import express from "express";
import cors from "cors";
import fetch from "node-fetch"; // npm i node-fetch if you don't already have it
import { OpenAI } from "openai";

const app = express();
app.use(express.json());
app.use(cors());

// Detect which backend to use
const HAS_OPENAI = !!process.env.OPENAI_API_KEY;
const OLLAMA_URL = process.env.OLLAMA_BASE_URL || "http://localhost:11434";
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || "mistral:7b";

const openai = HAS_OPENAI
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.post("/api/ai-remedies", async (req, res) => {
  try {
    const { profile, rules } = req.body || {};
    if (!profile) return res.status(400).json({ error: "Missing profile" });

    // Build one clean prompt (kept identical across backends)
    const prompt = [
      "You are a clinical assistant. Using the patient profile, vitals and rule output, produce a brief, actionable care plan.",
      "",
      "Return 3–6 bullet points total. Keep to practical steps and clear escalation criteria.",
      "",
      "Patient profile:",
      JSON.stringify(
        {
          name: profile.name,
          age: profile.age,
          conditions: profile.conditions || profile.condition || [],
          meds: profile.meds || [],
          lastVitals: (profile.vitals || []).slice(-1)[0] || null,
          hospital: profile.hospital || "",
          doctor: profile.doctor || "",
        },
        null,
        2
      ),
      "",
      "Rules engine output:",
      JSON.stringify(rules, null, 2),
    ].join("\n");

    let text = "";

    if (HAS_OPENAI) {
      // OpenAI path (in case you re-enable billing later)
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        temperature: 0.2,
        messages: [{ role: "user", content: prompt }],
      });
      text = completion.choices?.[0]?.message?.content?.trim() || "";
    } else {
      // OLLAMA path (free, local)
      // Non-streaming:
      const resp = await fetch(`${OLLAMA_URL}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: OLLAMA_MODEL,
          prompt,
          temperature: 0.2,
          stream: false,
        }),
      });
      if (!resp.ok) {
        const errText = await resp.text();
        throw new Error(`Ollama error: ${resp.status} ${errText}`);
      }
      const data = await resp.json(); // { response: "...", done: true, ... }
      text = (data.response || "").trim();
    }

    // Convert to a list (bullets or numbered)
    const plan =
      text
        .split("\n")
        .map((l) => l.replace(/^[\-\*\d\.\)\s]+/, "").trim())
        .filter(Boolean) || [];

    res.json({
      rationale: HAS_OPENAI
        ? "LLM plan (OpenAI)"
        : `LLM plan (Ollama: ${OLLAMA_MODEL})`,
      plan: plan.length ? plan : [text || "No response generated."],
    });
  } catch (err) {
    console.error("[AI] error:", err);
    // Graceful fallback so your UI still works
    res.status(200).json({
      rationale: "LLM unavailable — showing rule-based plan.",
      plan: (req.body?.rules?.recs || []).slice(0, 6),
    });
  }
});

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => console.log(`[API] AI server running on :${PORT}`));
// import "dotenv/config";
// import express from "express";
// import cors from "cors";
// import { OpenAI } from "openai";

// const app = express();
// app.use(express.json());
// app.use(cors());

// const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// app.get("/health", (_, res) => res.json({ ok: true }));

// app.post("/api/ai-remedies", async (req, res) => {
//   try {
//     const { profile, rules } = req.body || {};
//     if (!profile) return res.status(400).json({ error: "Missing profile" });

//     const prompt = [
//       "You are a clinical assistant. Using the patient profile, vitals and rule output, produce a brief, actionable care plan.",
//       "",
//       "Return 3–6 bullet points total. Keep to practical steps and escalation criteria.",
//       "",
//       "Patient profile:",
//       JSON.stringify(
//         {
//           name: profile.name,
//           age: profile.age,
//           conditions: profile.conditions || profile.condition || [],
//           meds: profile.meds || [],
//           lastVitals: (profile.vitals || []).slice(-1)[0] || null,
//           hospital: profile.hospital || "",
//           doctor: profile.doctor || "",
//         },
//         null,
//         2
//       ),
//       "",
//       "Rules engine output:",
//       JSON.stringify(rules, null, 2),
//     ].join("\n");

//     const completion = await openai.chat.completions.create({
//       model: "gpt-4o-mini",
//       temperature: 0.2,
//       messages: [{ role: "user", content: prompt }],
//     });

//     const text =
//       completion.choices?.[0]?.message?.content?.trim() ||
//       "No response generated.";
//     const plan = text
//       .split("\n")
//       .map((l) => l.replace(/^[\-\*\d\.\)\s]+/, "").trim())
//       .filter(Boolean);

//     res.json({
//       rationale: "LLM plan (GPT)",
//       plan: plan.length ? plan : [text],
//     });
//   } catch (err) {
//     console.error("AI error:", err);
//     res.status(500).json({ error: "AI server error" });
//   }
// });

// const PORT = process.env.PORT || 8787;
// app.listen(PORT, () => console.log(`AI server running on :${PORT}`));
