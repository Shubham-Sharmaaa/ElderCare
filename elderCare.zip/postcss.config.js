// import tailwindcss from "tailwindcss";
// import autoprefixer from "autoprefixer";

// export const plugins = [tailwindcss, autoprefixer];
// postcss.config.js
// postcss.config.js
export default {
  plugins: {
    // no tailwind here
    autoprefixer: {},
  },
};
