import React, { useMemo, useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { apiHospital, apiReports } from "../../lib/fakeApi";

export default function HospitalReports() {
  const { user } = useAuth();
  const elders = useMemo(() => apiHospital.elders(user.id), [user.id]);
  const [sel, setSel] = useState(elders[0]?.id || "");
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [rows, setRows] = useState(sel ? apiReports.listForElder(sel) : []);

  const load = (id) => setRows(apiReports.listForElder(id));

  const upload = () => {
    if (!sel || !title.trim() || !url.trim()) return;
    apiReports.upload({ elderId: sel, title: title.trim(), url: url.trim() });
    setTitle("");
    setUrl("");
    load(sel);
  };
  const approve = (id) => {
    apiReports.setStatus(id, "approved");
    load(sel);
  };

  return (
    <div className="grid">
      <div className="card pad">
        <h3>Upload Report</h3>
        <div className="grid two">
          <select
            value={sel}
            onChange={(e) => {
              setSel(e.target.value);
              load(e.target.value);
            }}
          >
            {elders.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </select>
          <input
            className="input"
            placeholder="Title (e.g., CBC - Aug 25)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <input
            className="input"
            placeholder="URL to PDF (or text)"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
        </div>
        <div style={{ marginTop: 8 }}>
          <button className="btn" onClick={upload} disabled={!sel}>
            Upload
          </button>
        </div>
      </div>

      <div className="card pad">
        <h3>Reports</h3>
        {rows.length === 0 ? (
          <p>No reports yet.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Title</th>
                <th>Status</th>
                <th>Link</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td>{new Date(r.tsISO).toLocaleString()}</td>
                  <td>{r.title}</td>
                  <td>{r.status}</td>
                  <td>
                    <a href={r.url} target="_blank" rel="noreferrer">
                      Open
                    </a>
                  </td>
                  <td>
                    {r.status !== "approved" && (
                      <button className="btn" onClick={() => approve(r.id)}>
                        Approve
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
