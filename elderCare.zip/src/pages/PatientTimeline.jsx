import React, { useMemo, useState } from "react";
import { apiElders, apiVitals } from "../lib/fakeApi";
import { useAuth } from "../context/AuthContext";

export default function PatientTimeline() {
  const { user } = useAuth();
  const elders = useMemo(() => apiElders.listByOwner(user.id), [user.id]);
  const [sel, setSel] = useState(elders[0]?.id || "");
  const list = useMemo(() => (sel ? apiVitals.recent(sel, 40) : []), [sel]);

  return (
    <div className="card pad">
      <h3>Vitals Timeline</h3>
      <select value={sel} onChange={(e) => setSel(e.target.value)}>
        {elders.map((e) => (
          <option key={e.id} value={e.id}>
            {e.name}
          </option>
        ))}
      </select>
      <div style={{ marginTop: 10 }}>
        {list.length === 0 && (
          <p>No data yet. Use “Simulate Vital” on Dashboard.</p>
        )}
        {list.map((v) => (
          <div
            key={v.id}
            style={{ borderTop: "1px solid #eee", padding: "8px 0" }}
          >
            <strong>{new Date(v.tsISO).toLocaleString()}</strong> — HR {v.hr}{" "}
            bpm · SpO₂ {v.spo2}% · BP {v.sys}/{v.dia}
          </div>
        ))}
      </div>
    </div>
  );
}
