// import React, { useEffect, useMemo, useState } from "react";
// import { useAuth } from "../context/AuthContext";
// import { apiElders, apiMeds } from "../lib/fakeApi";

// export default function Meds() {
//   const { user } = useAuth();
//   const [elders, setElders] = useState([]);
//   const [selected, setSelected] = useState("");
//   const [med, setMed] = useState("Atenolol");
//   const [time, setTime] = useState("08:00");
//   const [today, setToday] = useState([]);

//   useEffect(() => {
//     const list = apiElders.listByOwner(user.id);
//     setElders(list);
//     if (list[0]) setSelected(list[0].id);
//   }, [user.id]);

//   useEffect(() => {
//     if (selected) setToday(apiMeds.listTodayForElder(selected));
//   }, [selected]);

//   const addDose = () => {
//     if (!selected) return;
//     apiMeds.create({ elderId: selected, medicine: med, timeHHmm: time });
//     setToday(apiMeds.listTodayForElder(selected));
//   };

//   const toggle = (id) => {
//     apiMeds.toggleTaken(id);
//     setToday(apiMeds.listTodayForElder(selected));
//   };

//   return (
//     <div className="card">
//       <h2>Medication Schedule</h2>

//       <div className="grid3">
//         <select
//           className="form-input"
//           value={selected}
//           onChange={(e) => setSelected(e.target.value)}
//         >
//           {elders.map((e) => (
//             <option key={e.id} value={e.id}>
//               {e.name}
//             </option>
//           ))}
//         </select>
//         <input
//           className="form-input"
//           value={med}
//           onChange={(e) => setMed(e.target.value)}
//         />
//         <input
//           className="form-input"
//           type="time"
//           value={time}
//           onChange={(e) => setTime(e.target.value)}
//         />
//       </div>

//       <button className="button" onClick={addDose}>
//         Add
//       </button>

//       <div className="card" style={{ marginTop: "1rem" }}>
//         <h3>Today’s Doses</h3>
//         {!today.length && <i>No doses yet.</i>}
//         <ul>
//           {today.map((d) => (
//             <li key={d.id} style={{ margin: "0.25rem 0" }}>
//               {d.medicine} — {d.timeHHmm}
//               <button
//                 className={`tag ${d.taken ? "tag--green" : ""}`}
//                 onClick={() => toggle(d.id)}
//               >
//                 {d.taken ? "Taken" : "Mark Taken"}
//               </button>
//             </li>
//           ))}
//         </ul>
//       </div>
//     </div>
//   );
// }
import React, { useMemo, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { apiElders, apiMeds } from "../lib/fakeApi";

export default function Meds() {
  const { user } = useAuth();
  const elders = useMemo(() => apiElders.listByOwner(user.id), [user.id]);
  const [sel, setSel] = useState(elders[0]?.id || "");
  const [f, setF] = useState({ medicine: "Atenolol", timeHHmm: "08:00" });

  const list = useMemo(() => (sel ? apiMeds.listForElder(sel) : []), [sel]);

  const add = () => {
    apiMeds.add({ elderId: sel, ...f });
    setF({ medicine: "", timeHHmm: "08:00" });
  };
  const toggle = (id) => {
    apiMeds.toggle(id);
  };

  return (
    <div className="grid">
      <div className="card pad">
        <h3>Medication Schedule</h3>
        <div className="grid two">
          <select value={sel} onChange={(e) => setSel(e.target.value)}>
            {elders.map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}
              </option>
            ))}
          </select>
          <input
            className="input"
            placeholder="Medicine"
            value={f.medicine}
            onChange={(e) => setF({ ...f, medicine: e.target.value })}
          />
          <input
            className="input"
            type="time"
            value={f.timeHHmm}
            onChange={(e) => setF({ ...f, timeHHmm: e.target.value })}
          />
        </div>
        <div style={{ marginTop: 8 }}>
          <button className="btn" onClick={add}>
            Add
          </button>
        </div>
      </div>

      <div className="card pad">
        <h3>Today</h3>
        <table className="table">
          <thead>
            <tr>
              <th>Time</th>
              <th>Medicine</th>
              <th>Taken</th>
            </tr>
          </thead>
          <tbody>
            {list.map((m) => (
              <tr key={m.id}>
                <td>{m.timeHHmm}</td>
                <td>{m.medicine}</td>
                <td>
                  <button className="btn ghost" onClick={() => toggle(m.id)}>
                    Toggle
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
