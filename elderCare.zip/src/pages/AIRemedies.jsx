// import React, { useState } from "react";
// import { usePatients } from "../context/PatientContext";
// // import { callYourApi } from "../lib/gpt"; // optional later

// export default function AIRemedies() {
//   const { patients } = usePatients();
//   const [selectedId, setSelectedId] = useState(patients[0]?.id || "");
//   const [notes, setNotes] = useState("");
//   const [result, setResult] = useState("");

//   if (patients.length === 0) {
//     return (
//       <div className="card">
//         <h2>AI Remedies (GPT)</h2>
//         <p>
//           Please add a patient first in the <a href="/patients">Patients</a>{" "}
//           tab.
//         </p>
//       </div>
//     );
//   }

//   const onGenerate = async () => {
//     const p = patients.find((x) => x.id === selectedId);
//     // For now we just simulate. You can replace with your GPT API call.
//     const text = `Remedies for ${p.name} (${
//       p.condition || "unknown condition"
//     }):
// - Hydration, 7–8h sleep, 30min walk.
// - Monitor BP and SpO2 daily.
// - Diet: low-sodium, high-fiber.`;
//     setResult(text);
//   };

//   return (
//     <div className="card">
//       <h2>AI Remedies (GPT)</h2>
//       <div
//         style={{
//           display: "grid",
//           gridTemplateColumns: "240px 1fr 220px",
//           gap: 12,
//         }}
//       >
//         <select
//           className="form-input"
//           value={selectedId}
//           onChange={(e) => setSelectedId(e.target.value)}
//         >
//           {patients.map((p) => (
//             <option key={p.id} value={p.id}>
//               {p.name}
//             </option>
//           ))}
//         </select>
//         <input
//           className="form-input"
//           placeholder="optional note (symptoms, vitals, etc.)"
//           value={notes}
//           onChange={(e) => setNotes(e.target.value)}
//         />
//         <button className="button" onClick={onGenerate}>
//           Generate Remedies
//         </button>
//       </div>

//       {result && (
//         <div className="card" style={{ marginTop: 16, whiteSpace: "pre-wrap" }}>
//           {result}
//         </div>
//       )}
//     </div>
//   );
// }
import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { apiElders, apiAi } from "../lib/fakeApi";

export default function AIRemedies() {
  const { user } = useAuth();
  const [elders, setElders] = useState([]);
  const [selected, setSelected] = useState("");
  const [result, setResult] = useState(null);

  useEffect(() => {
    const list = apiElders.listByOwner(user.id);
    setElders(list);
    if (list[0]) setSelected(list[0].id);
  }, [user.id]);

  const gen = () => {
    const profile = apiAi.buildPatientProfile(selected);
    // Here’s where you’d call your backend /gpt with `profile`.
    // For now, produce a local, structured suggestion:
    if (!profile) return;
    setResult({
      summary: `Elder ${profile.name}, ${profile.age} yrs, condition: ${
        profile.condition || "—"
      }.`,
      suggestions: [
        "Daily 20–30 min light walk unless contra-indicated.",
        "Reduce sodium; keep fluids consistent if on diuretics.",
        "Check BP twice daily for a week; record unusual readings.",
        "Discuss medication timings with assigned doctor.",
      ],
      context: profile,
    });
  };

  return (
    <div className="card">
      <h2>AI Remedies (prototype)</h2>

      <div className="grid2">
        <select
          className="form-input"
          value={selected}
          onChange={(e) => setSelected(e.target.value)}
        >
          {elders.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </select>
        <button className="button" onClick={gen}>
          Generate Remedies
        </button>
      </div>

      {result && (
        <div className="card" style={{ marginTop: "1rem" }}>
          <p>
            <b>Summary:</b> {result.summary}
          </p>
          <p>
            <b>Suggestions:</b>
          </p>
          <ul>
            {result.suggestions.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ul>
          <details>
            <summary>Data sent to AI</summary>
            <pre style={{ whiteSpace: "pre-wrap" }}>
              {JSON.stringify(result.context, null, 2)}
            </pre>
          </details>
        </div>
      )}
    </div>
  );
}
