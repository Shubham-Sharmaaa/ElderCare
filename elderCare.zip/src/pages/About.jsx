import React from "react";
export default function About() {
  return (
    <div className="card pad">
      <h3>About</h3>
      <p>
        WellNest helps NRIs coordinate care for parents in India by linking
        hospitals, doctors, and wearable devices.
      </p>
    </div>
  );
}
