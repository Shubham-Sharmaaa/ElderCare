import React, { useState } from "react";
import { apiAdmin } from "../../lib/fakeApi";

export default function AdminDashboard() {
  const [name, setName] = useState("");
  const [hosp, setHosp] = useState(apiAdmin.listHospitals());

  const add = () => {
    if (!name.trim()) return;
    apiAdmin.createHospital(name.trim());
    setHosp(apiAdmin.listHospitals());
    setName("");
  };

  return (
    <div className="grid">
      <div className="card pad">
        <h3>Onboard Hospital</h3>
        <div className="row">
          <input
            className="input"
            placeholder="Hospital name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <button className="btn" onClick={add}>
            Add
          </button>
        </div>
      </div>

      <div className="card pad">
        <h3>Hospitals</h3>
        <ul>
          {hosp.map((h) => (
            <li key={h.id}>{h.name}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
