import React from "react";
import { apiAdmin } from "../../lib/fakeApi";

export default function Users() {
  const list = apiAdmin.listUsers();
  return (
    <div className="card pad">
      <h3>All Accounts</h3>
      <table className="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
          </tr>
        </thead>
        <tbody>
          {list.map((u) => (
            <tr key={u.id}>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td>{u.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
