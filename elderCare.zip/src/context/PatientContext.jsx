// import React, {
//   createContext,
//   useContext,
//   useEffect,
//   useState,
//   useMemo,
// } from "react";

// const LS_KEY = "wn_patients_v1";
// const PatientCtx = createContext();

// export function PatientProvider({ children }) {
//   const [patients, setPatients] = useState(() => {
//     try {
//       return JSON.parse(localStorage.getItem(LS_KEY)) || [];
//     } catch {
//       return [];
//     }
//   });

//   useEffect(() => {
//     localStorage.setItem(LS_KEY, JSON.stringify(patients));
//   }, [patients]);

//   const addPatient = (p) => {
//     const id = crypto.randomUUID?.() || String(Date.now());
//     setPatients((prev) => [...prev, { id, ...p }]);
//   };

//   const updatePatient = (id, patch) => {
//     setPatients((prev) =>
//       prev.map((p) => (p.id === id ? { ...p, ...patch } : p))
//     );
//   };

//   const removePatient = (id) =>
//     setPatients((prev) => prev.filter((p) => p.id !== id));

//   const value = useMemo(
//     () => ({ patients, addPatient, updatePatient, removePatient }),
//     [patients]
//   );
//   return <PatientCtx.Provider value={value}>{children}</PatientCtx.Provider>;
// }

// export const usePatients = () => useContext(PatientCtx);
// import React, {
//   createContext,
//   useContext,
//   useEffect,
//   useMemo,
//   useState,
// } from "react";

// const STORAGE_KEYS = {
//   patients: "wn_patients",
//   meds: "wn_meds", // { [patientId]: MedicationSchedule[] }
//   timeline: "wn_timeline", // { [patientId]: TimelineEvent[] }
// };

// const PatientContext = createContext(null);

// export function PatientProvider({ children }) {
//   const [patients, setPatients] = useState([]);
//   const [selectedPatientId, setSelectedPatientId] = useState(null);

//   // --- Load from localStorage on first mount
//   useEffect(() => {
//     try {
//       const saved = JSON.parse(
//         localStorage.getItem(STORAGE_KEYS.patients) || "[]"
//       );
//       setPatients(Array.isArray(saved) ? saved : []);
//       if (saved?.length && !selectedPatientId)
//         setSelectedPatientId(saved[0].id);
//     } catch (_) {
//       setPatients([]);
//     }
//   }, []);

//   // --- Persist patients whenever they change
//   useEffect(() => {
//     localStorage.setItem(STORAGE_KEYS.patients, JSON.stringify(patients));
//   }, [patients]);

//   // --- CRUD
//   const addPatient = (p) => {
//     const id = crypto.randomUUID();
//     const next = {
//       id,
//       name: p.name?.trim(),
//       age: Number(p.age) || 0,
//       condition: p.condition || "",
//       notes: p.notes || "",
//       hospitalId: p.hospitalId || null,
//       doctorId: p.doctorId || null,
//     };
//     setPatients((prev) => [...prev, next]);
//     if (!selectedPatientId) setSelectedPatientId(id);
//     return id;
//   };

//   const updatePatient = (id, patch) =>
//     setPatients((prev) =>
//       prev.map((p) => (p.id === id ? { ...p, ...patch } : p))
//     );
//   const deletePatient = (id) => {
//     setPatients((prev) => prev.filter((p) => p.id !== id));
//     setSelectedPatientId((s) => (s === id ? null : s));
//   };

//   // --- Medication helpers (scoped per patient)
//   const readMeds = (id) => {
//     const all = JSON.parse(localStorage.getItem(STORAGE_KEYS.meds) || "{}");
//     return all[id] || [];
//   };
//   const writeMeds = (id, arr) => {
//     const all = JSON.parse(localStorage.getItem(STORAGE_KEYS.meds) || "{}");
//     all[id] = arr;
//     localStorage.setItem(STORAGE_KEYS.meds, JSON.stringify(all));
//   };
//   const addMedDose = (id, dose) =>
//     writeMeds(id, [
//       ...readMeds(id),
//       { ...dose, id: crypto.randomUUID(), createdAt: Date.now() },
//     ]);
//   const toggleMedTaken = (id, doseId, taken = true) => {
//     const list = readMeds(id).map((d) =>
//       d.id === doseId ? { ...d, taken } : d
//     );
//     writeMeds(id, list);
//   };

//   // --- Timeline helpers (for vitals/alerts)
//   const readTimeline = (id) =>
//     JSON.parse(localStorage.getItem(STORAGE_KEYS.timeline) || "{}")[id] || [];
//   const pushTimeline = (id, event) => {
//     const all = JSON.parse(localStorage.getItem(STORAGE_KEYS.timeline) || "{}");
//     const list = all[id] || [];
//     all[id] = [...list, { id: crypto.randomUUID(), ts: Date.now(), ...event }];
//     localStorage.setItem(STORAGE_KEYS.timeline, JSON.stringify(all));
//   };

//   const value = useMemo(
//     () => ({
//       patients,
//       selectedPatientId,
//       setSelectedPatientId,
//       addPatient,
//       updatePatient,
//       deletePatient,
//       readMeds,
//       addMedDose,
//       toggleMedTaken,
//       readTimeline,
//       pushTimeline,
//     }),
//     [patients, selectedPatientId]
//   );

//   return (
//     <PatientContext.Provider value={value}>{children}</PatientContext.Provider>
//   );
// }

// export const usePatients = () => {
//   const ctx = useContext(PatientContext);
//   if (!ctx) throw new Error("usePatients must be used inside PatientProvider");
//   return ctx;
// };
// import React, {
//   createContext,
//   useContext,
//   useEffect,
//   useMemo,
//   useState,
// } from "react";
// import { apiElders } from "../lib/fakeApi";
// import { useAuth } from "./AuthContext";

// const PatientContext = createContext();
// export const usePatients = () => useContext(PatientContext);

// export function PatientProvider({ children }) {
//   const { user } = useAuth();
//   const [elders, setElders] = useState([]);
//   const [loading, setLoading] = useState(false);

//   // ✅ fetch only when the logged-in user id changes
//   useEffect(() => {
//     if (!user?.id || user.role !== "nri") {
//       setElders([]);
//       return;
//     }
//     setLoading(true);
//     Promise.resolve(apiElders.listByOwner(user.id))
//       .then((rows) => setElders(rows))
//       .finally(() => setLoading(false));
//   }, [user?.id, user?.role]);

//   const refresh = async () => {
//     if (!user?.id) return;
//     const rows = await Promise.resolve(apiElders.listByOwner(user.id));
//     setElders(rows);
//   };

//   // ✅ memoize the value so consumers don’t see a new object every render
//   const value = useMemo(
//     () => ({ elders, setElders, refresh, loading }),
//     [elders, loading]
//   );

//   return (
//     <PatientContext.Provider value={value}>{children}</PatientContext.Provider>
//   );
// }
// src/context/PatientContext.jsx
import React, {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { apiElders } from "../lib/fakeApi";
import { useAuth } from "./AuthContext";

const PatientContext = createContext(null);
export const usePatients = () => {
  const ctx = useContext(PatientContext);
  if (!ctx) throw new Error("usePatients must be used inside PatientProvider");
  return ctx;
};

export function PatientProvider({ children }) {
  const { user } = useAuth();
  const [elders, setElders] = useState([]);
  const [loading, setLoading] = useState(false);

  // Load elders for NRI owner
  useEffect(() => {
    if (!user?.id || user.role !== "nri") {
      setElders([]);
      return;
    }
    let alive = true;
    setLoading(true);
    Promise.resolve(apiElders.listByOwner(user.id))
      .then((rows) => {
        if (alive) setElders(rows);
      })
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [user?.id, user?.role]);

  const refresh = async () => {
    if (!user?.id) return;
    const rows = await Promise.resolve(apiElders.listByOwner(user.id));
    setElders(rows);
  };

  const value = useMemo(
    () => ({ elders, setElders, refresh, loading }),
    [elders, loading]
  );

  return (
    <PatientContext.Provider value={value}>{children}</PatientContext.Provider>
  );
}
